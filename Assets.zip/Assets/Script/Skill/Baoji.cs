namespace Script.Skill
{
    public class Baoji
    {
        
    }
}