namespace Script.Staff
{
    public class IronSword : Weapon
    {
        public IronSword()
        {
            Attack = 80;
            SpiritPath = "Staff/Iron Sword";
        }
    }
}