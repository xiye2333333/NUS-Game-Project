namespace Script.Staff
{
    public class GoldenSword : Weapon
    {
        public GoldenSword()
        {
            Attack = 300;
            SpiritPath = "Staff/Golden Sword";
        }
    }
}