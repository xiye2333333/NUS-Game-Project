namespace Script.Staff
{
    public class WoodenSword : Weapon
    {
        public WoodenSword()
        {
            SpiritPath = "Staff/Wooden Sword";
            Attack = 20;
        }
    }
}