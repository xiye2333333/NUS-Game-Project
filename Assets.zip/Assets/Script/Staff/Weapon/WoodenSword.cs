namespace Script.Staff
{
    public class WoodenSword : Weapon
    {
        public WoodenSword()
        {
            name = "Wooden Sword";
            info = "A good wooden sword\nAdd 20 attack power";
            SpiritPath = "Staff/Wooden Sword";
            Attack = 20;
        }
    }
}