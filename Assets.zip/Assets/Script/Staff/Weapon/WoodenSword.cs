namespace Script.Staff
{
    public class WoodenSword : Weapon
    {
        public WoodenSword()
        {
            name = "Wooden Sword";
            info = "A good wooden sword\nAdd 15 attack power";
            SpiritPath = "Staff/Wooden Sword";
            Attack = 15;
        }
    }
}