namespace Script.Staff
{
    public class Staff
    {
        public string name;
        public string info;
        public string SpiritPath = "";
    }
}