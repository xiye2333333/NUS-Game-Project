namespace Script.Staff
{
    public class Staff
    {
        public string SpiritPath = "";
    }
}