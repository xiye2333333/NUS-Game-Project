namespace Script.Staff
{
    public class Item : Staff
    {
        
    }
}