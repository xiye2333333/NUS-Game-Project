namespace Script.Staff.Boot
{
    public class IronBoot : Boot
    {
        public IronBoot()
        {
            HP = 100;
            MP = 0;
            Defence = 50;
            SpiritPath = "Staff/Iron Boot";
        }
    }
}