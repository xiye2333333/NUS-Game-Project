namespace Script.Staff.Shield
{
    public class IronShield : Shield
    {
        public IronShield()
        {
            Defence = 250;
            SpiritPath = "Staff/Iron Shield";
        }
    }
}