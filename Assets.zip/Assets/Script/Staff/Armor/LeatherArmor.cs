namespace Script.Staff.Armor
{
    public class LeatherArmor :Armor
    {
        public LeatherArmor()
        {
        HP = 20;
        MP = 0;//no define
        Defence = 10;
        SpiritPath = "Staff/Leather Armor";
        }
    }
}